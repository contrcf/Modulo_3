# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['calculadora']
install_requires = \
['dynaconf>=3.1.11,<4.0.0']

setup_kwargs = {
    'name': 'calculadora',
    'version': '0.1.0',
    'description': 'Calculadora de operacion basica',
    'long_description': '# Precondiciones\nSe asume que ya tiene Python 3+ instalado en su sistema. Si no, por favor, instalelo.  \n\nRevisar este link acorde a su sistema operativo: \n[Python 3 Installation & Setup Guide](https://realpython.com/installing-python/)\n\n# Instalación de ambiente virtual\nAbra una terminal, y dirijase a la carpeta raiz del proyecto, e instale `venv` con el siguiente comando.\n\n```\n$ pip3 install virtualenv\n```\nDespues, ejecute los siguientes comandos para crear el entorno virtual.\n```\n$ python3 -m venv ./venv\n```\nActive el entorno virtual.\n```\n$ source env/bin/activate\n```\n\n**Nota**: Desactive el entorno virtual usando este comando al terminar su practica.\n```\n$ deactivate\n```\n\n# Instalacion de bibliotecas\nPara instalar las bibliotecas necesarias, use este comando:\n```\npip3 install -r requirements.txt\n```\n\n¡Listo, la configuración está lista para las pruebas!\n\n## Probando el codigo\nCambie de directorio y ejecute el siguiente comando de la siguiente forma\n```\ncd sesion-3/app\npython ejemplo.py\n```\nDeberia ver la siguiente salida de datos\n```\n1.5\n0.5\n2.0\n0.5\n```\n\n\n## Ejecutar pruebas unitarias y de integracion\n* Pruebas unitarias\n```\npytest tests/unit/ -v\n```\n\n* Pruebas de integracion\n```\npytest tests/integration/ -v\n```',
    'author': 'Copernico Contreras',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
